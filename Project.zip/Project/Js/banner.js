
$(document).ready(function(){ 


	var cicloSlide = 0;

	function iniciarSlide(argument) {
		cicloSlide = setInterval(slideImagens,4000);
	}

	


	function slideImagens() {

			
	    if($('.imgActiva').next().length){

	        
	        $('.imgActiva').hide()
	        			   .removeClass("imgActiva")
	        			   .next()
	        			   .show()
	        			   .addClass("imgActiva");

	    }else{ 

	       
	        $('.imgActiva').hide()
	        			   .removeClass("imgActiva");
	        
	        $('#slideImagens img:eq(0)').show()
	        							.addClass("imgActiva");

	    }
		
	}


	function pararSlide(){
		clearInterval(cicloSlide);
	}


$("#Play").click(function(){
  iniciarSlide()
});

$("#Pause").click(function(){
  pararSlide();
});



	iniciarSlide();

})

